export class Food {
  name: string;
  make: string;
  quality: string;
  price: number;
}
