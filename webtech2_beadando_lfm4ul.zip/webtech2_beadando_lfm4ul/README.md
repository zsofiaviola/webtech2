# webtech2
Web technologies 2 assignment

Usage: 2 command lines (or terminal) required.

1st cmd:

– cd assignment

– npm install

– ng serve -o

2nd cmd:
– cd assignment

– node db.js
